ZenseMe (Windows Phone, Zune, MTP device scrobbler for Last.fm)
By Arnold Vink (Dumbie)
Release: v2.0.0

--------------------------------------------------------

Hi, thanks for using this app! Actually, I didn't really make it; they just pay me to talk about it.


USAGE:

1. Unzip this directory if you haven't done so already, and put it wherever you want

2. You will have to close out of the following media players before attempting to run ZenseMe: Zune, songbird, Media Go, MediaMonkey. I'm not sure why--presumably they can interfere with communication between this app and your device

3. I think it also helps to plug in your device before launching ZenseMe

4. Click "fetchsongs" to start loading up your playcounts. This writer finds that this step takes an awful long time. Maybe go get a coffee, or read something. The results will arrive in the "Recently Played" tab

5. The first time you fetch songs, you might have thousands upon thousands of listens to scrobble. I recommend selecting them all and clicking "Skip Tracks", because scrobbling these old plays might be a very time-intensive task. Plus it might include music you haven't listened to since high school

6. When you're ready to scrobble some tracks, click "Scrobble Tracks" in the "Recently Played" tab. The first time you do this, you will be taken to a browser to log in to your last.fm account. JavaScript will probably throw a couple errors at you, but that's fine. Once you've authorized ZenseMe on your last.fm account, close the browser window. You only have to do this once.

7. Repeat steps 2-4 whenever you want to scrobble some more


TROUBLE:

- If everything works but no plays show up on your profile, it might be a problem with your firewall (or so I'm told)

- If you accidentally or intentionally revoke authorization for ZenseMe in your last.fm account, open ZenseMe.exe.Config in a text editor. Find the line that says LastFM_SessionKey and delete the string of 32 random characters. It should now read <add key="LastFM_SessionKey" value="" />

- This app only works with one last.fm user. You can just copy the whole directory for multiple users.

- If you get any game-ending error messages, kindly copy the contents of the message and send to dustinross@live.com.


Happy scrobbling!
-Dusty Scott Ross, Aug. 2020